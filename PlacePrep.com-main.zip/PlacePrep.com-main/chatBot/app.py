from flask import Flask, render_template, request
from transformers import GPT2LMHeadModel, GPT2Tokenizer

app = Flask(__name__)

 
model_name = "gpt2-medium"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)


def generate_sql_query(prompt_text):
    try:

        specific_prompt = f"Get your own SQL Server\nSelect all records from the {prompt_text} table:"
        

        input_ids = tokenizer.encode(specific_prompt, return_tensors="pt", max_length=512, truncation=True)
        output = model.generate(input_ids, max_length=100, num_return_sequences=1, no_repeat_ngram_size=2)
        generated_text = tokenizer.decode(output[0], skip_special_tokens=True)
        

        generated_sql = extract_sql_response(generated_text)
        
        return generated_sql
    except Exception as e:
        return f"Error generating SQL query: {str(e)}"


def extract_sql_response(generated_text):
    if "SELECT" in generated_text:
        response_start_idx = generated_text.index("SELECT")
        generated_sql = generated_text[response_start_idx:].strip()
        return generated_sql
    else:
        return generated_text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def process_query():
    try:
        user_prompt = request.form['query']
        generated_sql = generate_sql_query(user_prompt)
        return render_template('result.html', prompt=user_prompt, generated_sql=generated_sql)
    except KeyError:
        return "Error: Please provide a valid query prompt."

if __name__ == '__main__':
    app.run(debug=True)
