from flask import Flask, render_template, request, jsonify
from transformers import GPT2LMHeadModel, GPT2Tokenizer

app = Flask(__name__)

# Initialize GPT-2 model and tokenizer
model_name = "gpt2-medium"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)

def generate_sql_query(prompt_text):
    try:
        # Construct a specific prompt for SQL query generation
        specific_prompt = f"Generate SQL query: {prompt_text}"

        # Tokenize the prompt
        input_ids = tokenizer.encode(specific_prompt, return_tensors="pt", max_length=512, truncation=True)

        # Generate text based on the input prompt
        output = model.generate(input_ids, max_length=100, num_return_sequences=1, no_repeat_ngram_size=2, early_stopping=True)

        # Decode the generated text
        generated_sql = tokenizer.decode(output[0], skip_special_tokens=True).strip()

        # Post-process the generated SQL to handle any token issues
        # Here you can add additional logic if needed to refine the generated SQL
        return generated_sql
    except Exception as e:
        return f"Error generating SQL query: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def process_query():
    try:
        user_prompt = request.json['query']
        generated_sql = generate_sql_query(user_prompt)
        return jsonify({'prompt': user_prompt, 'generated_sqls': [generated_sql]})
    except KeyError:
        return jsonify({'error': 'Please provide a valid query prompt.'}), 400

@app.route('/result', methods=['POST'])
def show_result():
    try:
        user_prompt = request.json['query']
        generated_sql = generate_sql_query(user_prompt)
        return render_template('result.html', prompt=user_prompt, generated_sqls=[generated_sql])
    except KeyError:
        return "Error: Please provide a valid query prompt."

if __name__ == '__main__':
    app.run(debug=True)
