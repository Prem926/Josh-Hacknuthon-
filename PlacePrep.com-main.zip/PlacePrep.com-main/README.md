# **PlacePrep.com**


## **Project Description**

Placeprep.com is a Educational website where anybody can learn about coding related topics and languages. Placeprep allows you to give mcq test, apart from that it has two logins one for user login and another for admin with email validation , this website was developed using HTML,SCSS,CSS,Javascript,Bootstrap & JSON Server.


## **Tech stacks used :**
To create this website following Tech stack is used by contributors.  
<br>
<img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white"/>
<img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white"/>
<img src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/> 
![Bootstrap](https://img.shields.io/badge/bootstrap-%23563D7C.svg?style=for-the-badge&logo=bootstrap&logoColor=white)
![SASS](https://img.shields.io/badge/SASS-hotpink.svg?style=for-the-badge&logo=SASS&logoColor=white)


* **JSON Server**
* **Document Object Model (DOM)**
* **SMTP API and Elastic Email**
* **FlatIcons**
* **FontAwesome**



# **Project Status**

Placeprep.com is now complete and fully functional. The team has successfully implemented all of the necessary features and functionality of the website.


<hr/>


## See Live
Visit the Deployed version using this <a href="https://place-prep-com-sigma.vercel.app/HomePage/index.html">link</a>  
<hr/>

## Team Members and Contributors

### Soumya Swaroop Sootar
- Github : soumyasootar
- Visit Github : https://github.com/soumyasootar
- Check out Linkedin : https://www.linkedin.com/in/soumya-swaroop-sootar-a4b708118/

### Himanshu Sharma
- Github : hero007noob
- Visit Github : https://github.com/hero007noob
- Check out Linkedin : https://www.linkedin.com/in/himanshu-s-747a0b133/


### Saurabh Sonvane
- Github : s17200
- Visit Github : https://github.com/s17200
- Check out Linkedin : http://linkedin.com/in/saurabh-sonvane-64106017b





